scoreboard players set @a[scores={inSwCheckG=1..}] inSwCheck 1
clear @a[nbt=!{Inventory:[{id:"minecraft:red_concrete_powder",Slot:0b}]},x=500,y=20,z=450,distance=..140,scores={ingame=..0,lobby=10..},gamemode=adventure,tag=!delay_items] minecraft:red_concrete_powder
item replace entity @a[nbt=!{Inventory:[{id:"minecraft:red_concrete_powder",Slot:0b}]},x=500,y=20,z=450,distance=..140,scores={ingame=..0,lobby=10..},gamemode=adventure,tag=!delay_items] hotbar.0 with minecraft:red_concrete_powder[custom_name={"italic":false,"text":"Not in game! (Throw to join)"}]
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.1 with minecraft:air

item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.3 with minecraft:air
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.4 with minecraft:air
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.5 with minecraft:air
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.6 with minecraft:air
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.7 with minecraft:air
item replace entity @a[x=500,y=20,z=450,distance=..140,gamemode=adventure] hotbar.8 with minecraft:air

#book for nerds
clear @a[nbt=!{Inventory:[{id:"minecraft:written_book",Slot:2b}]},x=500,y=20,z=450,distance=..140,gamemode=adventure,scores={lobby=10..},tag=!delay_items] written_book
item replace entity @a[nbt=!{Inventory:[{id:"minecraft:written_book",Slot:2b}]},x=500,y=20,z=450,distance=..140,gamemode=adventure,scores={lobby=10..},tag=!delay_items] hotbar.2 with minecraft:written_book[written_book_content={title:"Book for Nerds",author:"ChainsawNinja",generation:0,resolved:1b,pages:[[{"text":"Book for nerds","bold":true,"underlined":false},{"text":"\nGame Version 9.2.6","underlined":false,"bold":false},{"text":"\n\nLinks:","underlined":false},{"text":"\n\nDiscord","color":"dark_aqua","bold":false,"underlined":false,"hover_event":{"action":"show_text","value":[{"text":"Talk with the community and find out about upcoming tournaments. :)","color":"dark_green"}]},"click_event":{"action":"open_url","url":"https://discord.gg/6xatFYH"}},{"text":"\n\nSupport Me :3","color":"#1B4EA6","bold":false,"underlined":false,"hover_event":{"action":"show_text","value":[{"text":"Just letting me know you enjoy the game is enough, but if you are inclined, I have a Patreon.","color":"dark_aqua"}]},"click_event":{"action":"open_url","url":"https://www.patreon.com/chainsawninja"}},{"text":"\n\nPatch Notes","color":"#240E57","bold":false,"underlined":false,"hover_event":{"action":"show_text","value":[{"text":"My pastebin profile includes an archive of all previous patch notes as well.","color":"gold"}]},"click_event":{"action":"open_url","url":"https://pastebin.com/qz7gmP1F"}},{"text":"\n\nGitHub","bold":false,"underlined":false,"hover_event":{"action":"show_text","value":[{"text":"Download of world and all files. May be a slightly different version.","color":"gray"}]},"click_event":{"action":"open_url","url":"https://github.com/Tristan-Magers/dueltnt"}}]]}] 1

clear @a[nbt=!{Inventory:[{id:"minecraft:green_concrete_powder",Slot:0b}]},x=500,y=20,z=450,distance=..140,scores={ingame=1..,lobby=10..},gamemode=adventure,tag=!delay_items] minecraft:green_concrete_powder
item replace entity @a[nbt=!{Inventory:[{id:"minecraft:green_concrete_powder",Slot:0b}]},x=500,y=20,z=450,distance=..140,scores={ingame=1..,lobby=10..},gamemode=adventure,tag=!delay_items] hotbar.0 with minecraft:green_concrete_powder[custom_name={"italic":false,"text":"Joined game (Throw to leave)"}]
scoreboard players set @a[scores={ingame=..0,inSwCheck=1..}] ingame 3
scoreboard players set @a[scores={ingame=1,inSwCheck=1..}] ingame 2
execute as @a[scores={inSwCheck=1..}] at @s run playsound minecraft:block.dispenser.dispense master @p ~ ~ ~ 1 1.5
title @a[scores={ingame=2}] actionbar {"text":"Left game","color":"red"}
title @a[scores={ingame=3}] actionbar {"text":"Joined game","color":"dark_green"}
execute as @a[scores={inSwCheck=1..}] at @s run kill @e[type=item,distance=..3]
scoreboard players set @a[scores={ingame=3}] ingame 1
scoreboard players set @a[scores={ingame=2}] ingame 0
scoreboard players set @a inSwCheck 0
scoreboard players set @a inSwCheckG 0