setblock ~ ~ ~ air

kill @s